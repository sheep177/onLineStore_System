import java.util.ArrayList;
import java.util.Date;
import java.util.List;
//this part is to get details of customer order
class Order {
    private static int nextOrderId = 1;//use of static to make is accesible to all
    private final int orderId;
    private List<Item> items;
    private final Date dateOfPurchase;
    private double purchaseTotal;

    public Order() {
        this.orderId = nextOrderId++;
        this.items = new ArrayList<>();
        this.dateOfPurchase = new Date();
    }

    public void addItem(Item item) {
        items.add(item);//use of poly
        purchaseTotal += item.price;
    }

    public Date getDateOfPurchase() {
        return dateOfPurchase;
    }



    public String toString() {
        String result = "Order ID: " + orderId + "\nDate: " + dateOfPurchase + "\nItems:\n";
        for (Item item : items) {
            result += item.getDescription() + "\n";
        }
        result += "Total: " + String.format("%.2f", purchaseTotal);
        return result;
    }

}
