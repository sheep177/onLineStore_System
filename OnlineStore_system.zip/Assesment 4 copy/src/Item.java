abstract class Item {//use abstract for father class and so cant be instantiate
    //use protected they only be visible to subclass
    protected int itemNumber;
    protected String artistName;
    protected double price;
    protected int stockLevel;
    public Item(int itemNumber, String artistName, double price, int stockLevel) {
        this.itemNumber = itemNumber;
        this.artistName = artistName;
        this.price = price;
        this.stockLevel = stockLevel;
    }
    //Provides an interface for specific product types to express their unique attributes
    public abstract String getDescription();

}
