enum TShirtSize {
    SMALL, MEDIUM, LARGE, XLARGE
}
