interface StoreOperations {
    void addCustomer(String name);
    void listCustomers();
    void addItem(Item item);
    void listItems();
    void updateStock(int itemNumber, int newStock);
    void addOrder(int customerNumber, int itemNumber, int quantity);
    void listRecentOrders();
}
