import java.util.ArrayList;
import java.util.List;
//this part is to get the customer number and add order to specific customers

class Customer {
    private static int nextCustomerNumber = 1;
    int customerNumber;
    private String name;
    private List<Order> orders;//instantiate orders useing arraylist, store order info inside

    public Customer(String name) {
        this.customerNumber = nextCustomerNumber++;
        this.name = name;
        this.orders = new ArrayList<>();
    }

    public void addOrder(Order order) {
        orders.add(order);
    }// add oder to specific customer



    public String toString() {
        return String.format("Customer No.%d: %s", customerNumber, name);
    }
}

