class Record extends Item {//inheirate all protected property from Item
    //this part can be used to instantiate details of record
    private String albumName;

    public Record(int itemNumber, String artistName, double price, int stockLevel, String albumName) {
        super(itemNumber, artistName, price, stockLevel);//super to use father class Item's property in subclass
        this.albumName = albumName;
    }

    @Override
    public String getDescription() {
        return String.format("Record: %s by %s, Price: %.2f, Stock: %d", albumName, artistName, price, stockLevel);
    }
}
