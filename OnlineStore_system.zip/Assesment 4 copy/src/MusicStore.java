import java.util.*;
import java.util.stream.Collectors;

//this part is to code the logic for options in main program
public class MusicStore implements StoreOperations {
    private HashMap<Integer, Item> items = new HashMap<>();//integer store item no.
    private HashMap<Integer, Customer> customers = new HashMap<>();//integer store customer no.
    private List<Order> orders = new ArrayList<>();
    private int nextItemNumber = 1;


    public void addCustomer(String name) {
        Customer customer = new Customer(name); // straight instantiate customer, and customer number will ++ in customer Class
        customers.put(customer.customerNumber, customer);
        System.out.println("Customer added: " + customer);
    }


    public void addItem(Item item) {
        items.put(item.itemNumber, item);
    }


public void listCustomers() {
    //get all customer value in box
    Collection<Customer> allCustomers = customers.values();


    if (allCustomers.isEmpty()) {
        System.out.println("No customers found.");
    } else {

        for (Customer customer : allCustomers) {

            System.out.println(customer);//use of poly
        }
    }
}



public void listItems() {

    Collection<Item> allItems = items.values();


    if (allItems.isEmpty()) {
        System.out.println("No items available in the store.");
    } else {

        for (Item item : allItems) {

            String description = item.getDescription();
            System.out.println(description);//poly dynamic bond
        }
    }
}


    public void updateStock(int itemNumber, int newStock) {
        if (items.containsKey(itemNumber)) {
            items.get(itemNumber).stockLevel = newStock;
        }
    }

    public void addOrder(int customerNumber, int itemNumber, int quantity) {
        if (customers.containsKey(customerNumber) && items.containsKey(itemNumber) && items.get(itemNumber).stockLevel >= quantity) {
            Order order = new Order();
            Item item = items.get(itemNumber);
            for (int i = 0; i < quantity; i++) {
                order.addItem(item);
                item.stockLevel--;
            }
            customers.get(customerNumber).addOrder(order);
            orders.add(order);
        }
    }



public void listRecentOrders() {
    // the date one month ago
    Date oneMonthAgo = new Date(System.currentTimeMillis() - (30L * 24 * 60 * 60 * 1000));

    for (Order order : orders) {
        if (order.getDateOfPurchase().after(oneMonthAgo)) {
            System.out.println(order);
        }
    }
}



    public boolean isValidItemNumber(int itemNumber) {
        return items.containsKey(itemNumber);
    }

    public boolean isValidCustomerNumber(int customerNumber) {
        return customers.containsKey(customerNumber);
    }

    public boolean canFulfillOrder(int itemNumber, int quantity) {
        return items.containsKey(itemNumber) && items.get(itemNumber).stockLevel >= quantity;
    }

    public int generateItemNumber() {
        return nextItemNumber++;
    }
}
