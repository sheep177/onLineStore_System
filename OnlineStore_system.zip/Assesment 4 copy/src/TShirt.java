class TShirt extends Item {//inheirate all public from Item
    //this part can be used to instantiate details of Tshirt
    private TShirtSize size;//type defined in enum to make easier access，because size are fixed, not flexible like description

    public TShirt(int itemNumber, String artistName, double price, int stockLevel, TShirtSize size) {
        super(itemNumber, artistName, price, stockLevel);
        this.size = size;
    }

    @Override
    public String getDescription() {
        return String.format("T-Shirt: %s Size %s, Price: %.2f, Stock: %d", artistName, size, price, stockLevel);
    }
}
