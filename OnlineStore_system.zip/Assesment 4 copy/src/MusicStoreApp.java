import java.util.Scanner;
//this part is the main program

public class MusicStoreApp {
    public static void main(String[] args) {
        new MusicStoreApp().run();
    }
    private MusicStore store;
    private Scanner scanner;

    public MusicStoreApp() {
        this.store = new MusicStore();
        this.scanner = new Scanner(System.in);
    }

    public void run() {
        boolean exit = false;
        while (!exit) {
            System.out.println("\n--- Music Store Management System ---");
            System.out.println("1. Add a new customer");
            System.out.println("2. Display a list of all customers");
            System.out.println("3. Add a new record to the store inventory");
            System.out.println("4. Add a new t-shirt to the store inventory");
            System.out.println("5. Display a list of all items and their current stock levels");
            System.out.println("6. Update the stock level of an item in the inventory");
            System.out.println("7. Enter and store the details of a new customer order");
            System.out.println("8. Output a list of all orders placed in the current month");
            System.out.println("9. Exit the program");
            System.out.print("Select an option: ");

            int choice = scanner.nextInt();
            scanner.nextLine(); // clear the buffer
            if (choice == 1) {
                addCustomer();
            } else if (choice == 2) {
                store.listCustomers();
            } else if (choice == 3) {
                addRecord();
            } else if (choice == 4) {
                addTShirt();
            } else if (choice == 5) {
                store.listItems();
            } else if (choice == 6) {
                updateStock();
            } else if (choice == 7) {
                addOrder();
            } else if (choice == 8) {
                store.listRecentOrders();
            } else if (choice == 9) {
                exit = true;
            } else {
                System.out.println("Invalid option. Please try again.");
            }
        }
    }

    private void addCustomer() {
        System.out.print("Enter customer name: ");
        String name = scanner.nextLine();
        store.addCustomer(name);
        System.out.println("Customer added.");
    }

    private void addRecord() {
        System.out.print("Enter artist name: ");
        String artist = scanner.nextLine();
        System.out.print("Enter album name: ");
        String album = scanner.nextLine();
        System.out.print("Enter price: ");
        double price = scanner.nextDouble();
        System.out.print("Enter stock level: ");
        int stock = scanner.nextInt();
        scanner.nextLine();  // clear the buffer
        Record record = new Record(store.generateItemNumber(), artist, price, stock, album);
        store.addItem(record);
        System.out.println("Record added to inventory.");
    }

    private void addTShirt() {
        System.out.print("Enter artist name: ");
        String artist = scanner.nextLine();
        System.out.print("Enter size (SMALL, MEDIUM, LARGE, XLARGE): ");
        String sizeInput = scanner.nextLine().toUpperCase();


        if (isValidSize(sizeInput)) {
            TShirtSize size = TShirtSize.valueOf(sizeInput);
            System.out.print("Enter price: ");
            double price = scanner.nextDouble();
            System.out.print("Enter stock level: ");
            int stock = scanner.nextInt();
            scanner.nextLine();  // clear the buffer
            TShirt tShirt = new TShirt(store.generateItemNumber(), artist, price, stock, size);
            store.addItem(tShirt);
            System.out.println("T-shirt added to inventory.");
        } else {
            System.out.println("Invalid size entered. Please use one of the following sizes: SMALL, MEDIUM, LARGE, XLARGE.");
        }
    }


    private boolean isValidSize(String sizeInput) {
        for (TShirtSize size : TShirtSize.values()) {
            if (size.name().equals(sizeInput)) {
                return true;
            }
        }
        return false;
    }


    private void updateStock() {
        System.out.print("Enter item number: ");
        int itemNumber = scanner.nextInt();
        if (store.isValidItemNumber(itemNumber)) {
            System.out.print("Enter new stock level: ");
            int newStock = scanner.nextInt();
            scanner.nextLine();  // clear the buffer
            store.updateStock(itemNumber, newStock);
            System.out.println("Stock updated.");
        } else {
            System.out.println("Item number does not exist.");
        }
    }

    private void addOrder() {
        System.out.print("Enter customer number: ");
        int customerNumber = scanner.nextInt();
        if (!store.isValidCustomerNumber(customerNumber)) {
            System.out.println("Customer number does not exist.");
            return;
        }
        System.out.print("Enter item number: ");
        int itemNumber = scanner.nextInt();
        if (!store.isValidItemNumber(itemNumber)) {
            System.out.println("Item number does not exist.");
            return;
        }
        System.out.print("Enter quantity: ");
        int quantity = scanner.nextInt();
        if (!store.canFulfillOrder(itemNumber, quantity)) {
            System.out.println("Not enough stock to fulfill order.");
            return;
        }
        scanner.nextLine();  // clear the buffer
        store.addOrder(customerNumber, itemNumber, quantity);
        System.out.println("Order successfully added.");
    }


}
